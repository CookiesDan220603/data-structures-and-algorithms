import java.util.*;
public interface QueueADT {
public boolean isEmpty();
public Fraction peek();
public Fraction poll(); 
public boolean offer(Fraction item); 
public void print();
}