import java.util.Arrays;

public class test {
    public static void heapSort(int[] arr){
        MaxHeap temp = new MaxHeap(arr.length);
        for(int x: arr){
            temp.insert(x);
        }
        for(int i = 0; i < arr.length; i++){
            arr[i] = temp.extractMax();
        }
    }

    public static void main(String[] args) {
        int a[] = {15, 23, 18, 63, 21, 35, 36, 21, 66, 12, 42, 35, 75, 23, 64, 78, 39};
        heapSort(a);
        System.out.println(Arrays.toString(a));
    }
}
