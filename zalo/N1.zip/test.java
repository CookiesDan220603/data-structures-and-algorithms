import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class test {
    public static void NLR(Node x, FileWriter myWriter){
        if(x!= null){
            try{
                myWriter.write(x.key + " ");
            }catch(IOException e){
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
            NLR(x.left, myWriter);
            NLR(x.right, myWriter);
        }
    }

    public static void LNR(Node x, FileWriter myWriter){
        if(x != null){
            LNR(x.left, myWriter);
            try{
                myWriter.write(x.key + " ");
            }catch(IOException e){
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
            LNR(x.right, myWriter);
        }
    }

    public static void LRN(Node x, FileWriter myWriter){
        if(x != null){
            LRN(x.left, myWriter);
            LRN(x.right, myWriter);
            try{
                myWriter.write(x.key + " ");
            }catch(IOException e){
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
        }
    }

    public static AVL createAVL(String strKey){
        AVL avl = new AVL();
        String str[] = strKey.split(" ");
        for(String x: str){
            avl.insert(Integer.valueOf(x));
        }
        return avl;
    }

    public static void main(String[] args) {
        try {
            File myReader = new File("input.txt");
            Scanner sc = new Scanner(myReader);
            String data = "";
            while(sc.hasNextLine()){
                data = sc.nextLine();
            }
            sc.close();
            try{
                FileWriter myWriter = new FileWriter("output.txt");
                AVL avl = createAVL(data);
                myWriter.write("NLR: ");
                NLR(avl.root, myWriter);
                myWriter.write("\nLNR: ");
                LNR(avl.root, myWriter);
                myWriter.write("\nLRN: ");
                LRN(avl.root, myWriter);
                myWriter.write("\n");
                myWriter.close();
            }catch(IOException e){
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            System.out.println("Find not found.");
            e.printStackTrace();
        }
    }
}
