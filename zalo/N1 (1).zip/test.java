public class test {
    public static BST createTree(String strKey){
        BST bst = new BST();
        String str[] = strKey.split(" ");
        for(String x: str){
            bst.insert(Integer.valueOf(x));
        }
        return bst;
    }

    public static void main(String[] args) {
        BST bst = createTree("63 41 88 40 60 30 53 28 72 70 92");
        // bst.NLR(bst.root);
        // bst.printASC();
        // bst.printDESC();
        // System.out.println();
        bst.delete_pre(63);
        // System.out.println(bst.sum());
        bst.LNR(bst.root);
        System.out.println(bst.contains(60));
    }
}
