public class BST {
    Node root;

    public BST(){
        this.root = null;
    }

    public void insert(Integer key){
        this.root = insert(root, key);
    }

    private Node insert(Node x, Integer key){
        if(x == null)
            return new Node(key);
        int cmp = key.compareTo(x.key);
        if(cmp < 0)
            x.left = insert(x.left, key);
        else if(cmp > 0)
            x.right = insert(x.right, key);
        else
            x.key = key;
        return x;
    }

    public void NLR(Node x){
        if(x!= null){
            System.out.print(x.key + " ");
            NLR(x.left);
            NLR(x.right);
        }
    }

    public void LNR(Node x){
        if(x != null){
            LNR(x.left);
            System.out.print(x.key + " ");
            LNR(x.right);
        }
    }

    public void LRN(Node x){
        if(x != null){
            LRN(x.left);
            LRN(x.right);
            System.out.print(x.key + " ");
        }
    }

    public Node search(Integer key){
        return search(this.root, key);
    }

    private Node search(Node x, Integer key){
        if(x == null)
            return null;
        int cmp = key.compareTo(x.key);
        if(cmp < 0)
            return search(x.left, key);
        else if(cmp > 0)
            return search(x.right, key);
        else 
            return x;
    }

    public Node min(){
        return min(this.root);
    }

    private Node min(Node x){
        if(x.left == null)
            return x;
        return min(x.left);
    }

    public Node max(){
        return max(this.root);
    }

    private Node max(Node x){
        if(x.right == null)
            return x;
        return max(x.right);
    }

    public void deleteMin(){
        this.root = deleteMin(this.root);
    }

    private Node deleteMin(Node x){
        if(x.left == null)
            return x.right;
        x.left = deleteMin(x.left);
        return x;
    }

    public void delete(Integer key){
        this.root = delete(this.root, key);
    }

    private Node delete(Node x, Integer key){
        if(x == null) return null;
        int cmp = key.compareTo(x.key);
        if(cmp < 0)
            x.left = delete(x.left, key);
        else if(cmp > 0)
            x.right = delete(x.right, key);
        else{
            if(x.right == null)
                return x.left;
            if(x.left == null)
                return x.right;
            x.key = min(x.right).key;
            x.right = deleteMin(x.right);
        }
        return x;
    }

    public void printASC(){
        LNR(this.root);
    }

    public void printDESC(){
        printDESC(this.root);
    }

    private void printDESC(Node x){
        if(x!=null){
            printDESC(x.right);
            System.out.print(x.key + " ");
            printDESC(x.left);
        }
    }

    public boolean contains(Integer key){
        if(search(key)!=null) return true;
        return false;
    }

    public void deleteMax(){
        Node max = max();
        delete(max.key);
    }

    public Node deleteMax(Node x){
        if(x.right == null)
            return x.left;
        x.right = deleteMax(x.right);
        return x;
    }

    public void delete_pre(Integer key){
        delete_pre(this.root, key);
    }
    
    private Node delete_pre(Node x, Integer key){
        if(x == null) return null;
        int cmp = key.compareTo(x.key);
        if(cmp < 0)
            x.left = delete_pre(x.left, key);
        else if(cmp > 0)
            x.right = delete_pre(x.right, key);
        else{
            if(x.right == null)
                return x.left;
            if(x.left == null)
                return x.right;
            x.key = max(x.left).key;
            x.left = deleteMax(x.left);
        }
        return x;
    }

    public int height(){
        return height(this.root);
    }

    private int height(Node x){
        if(x.left == null && x.right == null) return 0;
        if(x.left == null)
            return height(x.right) + 1;
        if(x.right == null)
            return height(x.left) + 1;
        return ((height(x.left) > height(x.right))?height(x.left):height(x.right)) + 1;
    }

    public Integer sum(Node x){
        if(x == null) return 0;
        return sum(x.left) + sum(x.right) + x.key;
    }

    public Integer sum(){
        return sum(this.root);
    }
}
