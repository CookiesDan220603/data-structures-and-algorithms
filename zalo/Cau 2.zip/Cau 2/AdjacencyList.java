import java.util.*;
import java.io.*;

public class AdjacencyList {
	private int V; 
	private LinkedList <Integer > adj[];
	
	@SuppressWarnings("unchecked")
	public AdjacencyList(int v) {
		V = v;
		adj = new LinkedList[v];
		for (int i=0; i<v; ++i)
		adj[i] = new LinkedList <Integer >();
	}
	
	public void addEdge(int u, int v) {
		adj[u].add(v);
	}
	
	public void printGraph() {
		for(int i = 0; i < V; i++) {
			if(adj[i].size()>0) {
				System.out.print("Vertex " + i + ": ");
				System.out.print("head");
				for(Integer v: adj[i]) {
					System.out.print("->" + v);
				}
				System.out.println();
			}
		}
	}
	
	public void countVertices() {
		int numofvertices = 0;
		for(int i = 0; i < V; i++) {
			numofvertices += 1;
		}
		System.out.println("The number of vertices is: " + numofvertices);
	}
	
	public void countEdges() {
		int numofedges = 0;
		for(int i = 0; i < V; i++) {
			if(adj[i].size()>0) {
				numofedges += adj[i].size();
			}
		}
		System.out.println("The number of edges is: " + numofedges);
	}
		
	public boolean checkExistence(int u, int v) {
		for(int i = 0; i < V; i++) {
			if (i == u) {
				for(Integer x: adj[i]) {
					if (x == v) {
						return true;
					}
				}
			}
		}
		return false;
	}
	
	public static void main(String[] args) {
		try {
			File f = new File("input.txt");
			Scanner sc = new Scanner(f);
			AdjacencyList test = new AdjacencyList(sc.nextInt());
			while (sc.hasNextLine()) {
				String s = sc.nextLine();
				String[] a = s.split(" ", -1);
				for (int i = 0; i < 1; ++i) {
					try {
						int x = Integer.parseInt(a[i]);
						for (int j = i+1; j < a.length; ++j) {
							try {
								int y = Integer.parseInt(a[j]);
								test.addEdge(x, y);
							} catch(Exception ex) {
								break;
							}
						}
					} catch(Exception ex) {
						break;
					}
				}
			}
			test.printGraph();
			test.countVertices();
			test.countEdges();
			if (test.checkExistence(5, 6) == true) {
				System.out.println("The edge between 5 and 6 exists.");
			}
			else {
				System.out.println("The edge between 5 and 6 does not exist.");
			}	
		} catch (IOException err) {
			System.out.println(err);
		}
	}
}